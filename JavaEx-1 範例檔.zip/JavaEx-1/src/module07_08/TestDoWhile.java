package module07_08;
/*
 * 此範例為do-while迴圈測試
 */
public class TestDoWhile {

	public static void main(String[] args) {
		int i = 100;

		do {
			System.out.println(i);
			i++;
		} while (i <=10);
	}

}
