package module01_06;
/*
 * 此範例為三元運算子測試
 * 可自行更換變數值比較結果
 */
public class TestTernaryOP {

	public static void main(String[] args) {
		int income = 10000, outcome = 12000;
		System.out.println((income > outcome) ? "有積蓄" : "入不敷出");
	}

}
