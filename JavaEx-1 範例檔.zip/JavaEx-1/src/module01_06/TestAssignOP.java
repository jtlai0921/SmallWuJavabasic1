package module01_06;
/*
 * 此範例為指定運算子測試
 */
public class TestAssignOP {

	public static void main(String[] args) {
		int num = 1;
		num += 2;    
		String s = "1";
		s += 2;  
		System.out.println(num);
		System.out.println(s);
	}

}
