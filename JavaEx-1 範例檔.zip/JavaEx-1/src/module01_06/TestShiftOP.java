package module01_06;

public class TestShiftOP {

	public static void main(String[] args) {
		int num = 1;
		System.out.println("2的1次方 = " + (num << 1));
		System.out.println("2的2次方 = " + (num << 2));
		System.out.println("2的3次方 = " + (num << 3));
	}

}
