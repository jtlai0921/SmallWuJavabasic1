package strategy.good;

public interface IRunBehavior {
	void run();
}
