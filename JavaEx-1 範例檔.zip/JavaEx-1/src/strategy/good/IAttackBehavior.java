package strategy.good;

public interface IAttackBehavior {
	void attack();
}
