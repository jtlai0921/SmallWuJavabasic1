package strategy.good;

public interface IDefendBehavior {
	void defend();
}
