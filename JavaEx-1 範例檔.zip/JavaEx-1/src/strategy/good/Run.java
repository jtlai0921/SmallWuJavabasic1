package strategy.good;

public class Run implements IRunBehavior {

	@Override
	public void run() {
		System.out.println("跑起來！");
	}

}
