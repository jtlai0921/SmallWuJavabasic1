package strategy.good;

public class Poppy extends Hero {
	
	public Poppy(String name) {
		this.name = name;
	}

}
