package module12_15;

public class TestMainArray {
    public static void main(String[] args) {
        System.out.println("貓的英文是：" + args[0] + args[1] + args[2]);
    }
}

