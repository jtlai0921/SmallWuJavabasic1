package module16_19;
/*
 * 設計類別時的不好示範
 * 資料操作安全性考量
 * 搭配PenTestNG.java使用
 */
public class PenNG {
	public String brand;
	public double price;
	
}
