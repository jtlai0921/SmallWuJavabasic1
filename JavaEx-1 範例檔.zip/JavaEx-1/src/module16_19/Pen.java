package module16_19;
/*
 * 設計此類別與PenTest.java一起使用
 * 暸解封裝的觀念
 */
public class Pen {
	private String brand;
	private double price;
}
