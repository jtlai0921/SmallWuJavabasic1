package module27_30;

public class HelloWorld {

	// override Object 類別的 toString() 方法
//	public String toString() {
//		System.out.println("HelloWorld! 世界你好 toString!");
//		return "";
//	}
}
