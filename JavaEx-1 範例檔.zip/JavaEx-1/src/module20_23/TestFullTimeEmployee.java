package module20_23;

public class TestFullTimeEmployee {

	public static void main(String[] args) {
		 FullTimeEmployee f1 = new FullTimeEmployee(7002 ,"David", 50000.0 );          
         f1.display();
	}

}
