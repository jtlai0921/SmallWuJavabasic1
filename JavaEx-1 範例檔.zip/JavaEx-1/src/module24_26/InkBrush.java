package module24_26;

public class InkBrush {
	public void write() {
		System.out.println("用毛筆寫字");
	}
}
