package module24_26;

public class InkBrush2 implements IWritable {
	public void write() {
		System.out.println("用毛筆寫字");
	}

}
