package module24_26;

public interface IWritable {
	void write();
}
